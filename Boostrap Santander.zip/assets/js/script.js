  function desplegar(){
            document.getElementById('menu').style.transform = 'translate(0%, 0%)';
        }

        function cerrarMenu(){
            document.getElementById('menu').style.transform = 'translate(-100%, 0%)';
        }